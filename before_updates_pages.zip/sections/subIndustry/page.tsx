import Hero from "@/components/hero/page"

interface pagesProps {
    slug:  string ;
  }
const SubIndustry = ({slug } : pagesProps)=>{
    return(<div className={`pb-16`} >
        <Hero title="Industries" description="Industries we Serve" link="/aboutUs/industry" pathFirst="Industries" pathSecond={slug} />
        <div>
            <img src="/bank.webp" alt="bank" />
        </div>
    </div>)
}

export default SubIndustry