import About from "@/sections/aboutUs/page"

const AboutPage = ()=>{
    return(<About/>)
}
export default AboutPage