import HomePage from "@/sections/home/page";



export default function Home() {
  return (<HomePage/>
  );
}
